import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String[] input = sc.nextLine().split("\\s+");
        Pizza pizza = null;
        try {
            pizza = new Pizza(input[1], Integer.parseInt(input[2]));
            input = sc.nextLine().split("\\s+");
            try {
                Dough dough = new Dough(input[1], input[2], Double.parseDouble(input[3]));
                pizza.setDough(dough);
            } catch (Exception e) {
                System.out.println(e.getMessage());
                return;
            }
            String line = "";

            while (!"END".equals(line = sc.nextLine())) {
                input = line.split("\\s+");
                try {
                    Topping topping = new Topping(input[1], Double.parseDouble(input[2]));
                    pizza.addTopping(topping);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                    return;
                }

            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return;
        }

            System.out.printf("%s - %.2f", pizza.getName(), pizza.getOverallCalories());

    }
}